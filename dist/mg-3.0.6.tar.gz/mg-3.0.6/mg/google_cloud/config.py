import os

GCP_PROJECT_NUMBER = os.getenv("MG_GCP_PROJECT_NUMBER")